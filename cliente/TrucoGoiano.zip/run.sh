#!/bin/bash

# Nome do arquivo principal
EXECUTABLE="linuxBuild/TrucoGoiano.x86_64"

# Torna o arquivo executável
chmod +x $EXECUTABLE

# Executa o programa
./$EXECUTABLE
